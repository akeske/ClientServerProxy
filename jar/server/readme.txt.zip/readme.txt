open the pdf file for the report
